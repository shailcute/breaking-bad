import React from 'react';
class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    componentDidMount() {
        }
            render() {

        return (
            <div className="body">
            <div className="cont s-signup">
             <div className="sub-cont">
              <div className="img">
                <div className="img-text m-up">
                  <h2>New here?</h2>
                  <p>Sign up and discover great amount of new opportunities!</p>
                </div>
                <div className="img-text m-in">
                  <h2>One of us?</h2>
                  <p>If you already has an account, just sign in. We've missed you!</p>
                </div>
                <div className="img-btn">
                  
                  <a href="/" className="m-in">Sign In</a>
                </div>
              </div>
              <div className="form sign-up">
                <h2>Sign Up</h2>
                <label>
                  <span>Name</span>
                  <input type="text" />
                </label>
                <label>
                  <span>Email</span>
                  <input type="email" />
                </label>
                <label>
                  <span>Password</span>
                  <input type="password" />
                </label>
                <label>
                  <span>Confirm Password</span>
                  <input type="password" />
                </label>
                <button type="button" className="submit">Sign Up Now</button>
              </div>
            </div>
          </div>
          </div>
           )
    }
}

export default Register;