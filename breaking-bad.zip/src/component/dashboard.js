import React from 'react';
import axios from "axios";
class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.showdetail = this.showdetail.bind(
            this
          );
        this.state = {
           charcard:"",
           showData : false
        }
       
    }
    
    showdetail(){
        console.log(this.state.showData);
        this.setState(state => ({
            showData: !state.showData
          }));
      
    }
    componentDidMount() {
        axios.get("https://www.breakingbadapi.com/api/characters")
          .then(response => {
            console.log("course list ", response);
            const chardata = response.data;
           
           let allChar = chardata.map((chardata,i) =>  (
                <div className="charCard" key={chardata.char_id}>
                  <div id="2burg" tabindex="0" className="sc-EHOje jaGwnY"  onClick={this.showdetail}>
                      <div id="2burga" width="30px" class="sc-bZQynM fgPKig"></div>
                      <div id="2burgb" width="40px" class="sc-bZQynM gCILqu"></div>
                      <div id="2burgc" width="22px" class="sc-bZQynM lfMqRr"></div>
                    </div>
                 <img className="char_img" src={chardata.img} alt="Jesse Pinkman" />
                 
                   <div className= {"char_btm " + (this.state.showData ? "btm2" : "")} >
                     <p className="sc-gzVnrw btPmOt">{chardata.name}</p>
                   <div className="">
                    <img className="bee_logo" src="https://images-na.ssl-images-amazon.com/images/I/31NhsG8XFpL._SX425_.jpg" alt="" />
                    <p> {chardata.nickname}</p>
                    </div>
                    {this.state.showData ? (
                    <div className="hidden_info">
                        <div><p>Id</p><p>2</p>
                        </div>
                        <div><p>Occupation</p><p className="occ_map">Meth Dealer</p>
                        </div>
                        <div>
                            <p>Breaking Bad Seasons</p>1,2,3,4,5
                        </div><div>
                            <p>Status</p>
                            <p>Alive</p>
                            </div>
                            </div>
                     ): ("")}
                 </div>
                 </div>
            //   <tr key={course._id}>
            //      <td>{i+1}</td>
            //     <td>{course.title}</td>
            //     {this.courseStatus(course)}
            //     <td>{course.level}</td>
            //     {this.coursePrice(course)}
            //     {this.coursepublishedDt(course)}
            //     <td  onClick={() => this.editCourse(course._id)} className="editCourse"><i class="fa fa-edit"></i></td>
            //     <td>
            //       <div className="courseRating">
                 
            //         <Button
            //           value={course._id}
            //           onClick={() =>this.finalDataSubmitted(course._id)}
            //           type="primary"
            //           href ="/microsite"
            //           target="_blank"
            //         >
            //           View Microsite
            //         </Button>
            //       </div>
            //     </td>
            //   </tr>
            ));
            this.setState({
                charcard: allChar
            });
          })
          .catch(error => {
            console.log(error);
          });
        }
            render() {
                console.log("render() method");
                console.log(this.state.showData);
        return (
            <div className="charlist" >
                <h1  onClick={() => this.showdetail()}>The Breaking Bad Characters</h1>
                <div className="charlist-" >
                     {this.state.charcard}
                </div>
            </div>
           )
    }
}

export default Dashboard;